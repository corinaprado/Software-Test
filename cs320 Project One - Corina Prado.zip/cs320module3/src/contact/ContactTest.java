package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

    @Test
    void testValidContactCreation() {

        Contact contact = new Contact(
                "12345",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street");

        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Smith", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    void testNullContactId() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(null, "John", "Smith",
                        "1234567890", "Address"));
    }

    @Test
    void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345678901", "John", "Smith",
                        "1234567890", "Address"));
    }

    @Test
    void testNullFirstName() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", null, "Smith",
                        "1234567890", "Address"));
    }

    @Test
    void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "VeryLongName",
                        "Smith", "1234567890", "Address"));
    }

    @Test
    void testNullLastName() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", null,
                        "1234567890", "Address"));
    }

    @Test
    void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John",
                        "VeryLongLastName",
                        "1234567890",
                        "Address"));
    }

    @Test
    void testNullPhone() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", "Smith",
                        null, "Address"));
    }

    @Test
    void testPhoneTooShort() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", "Smith",
                        "12345", "Address"));
    }

    @Test
    void testPhoneContainsLetters() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", "Smith",
                        "12345ABCDE", "Address"));
    }

    @Test
    void testNullAddress() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", "Smith",
                        "1234567890", null));
    }

    @Test
    void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("1", "John", "Smith",
                        "1234567890",
                        "This address is definitely longer than thirty characters"));
    }
}