package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServiceTest {

    @Test
    void testAddContact() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main St");

        service.addContact(contact);

        assertNotNull(service.getContact("001"));
    }

    @Test
    void testDeleteContact() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main St");

        service.addContact(contact);
        service.deleteContact("001");

        assertNull(service.getContact("001"));
    }

    @Test
    void testDuplicateContactId() {

        ContactService service = new ContactService();

        Contact contact1 = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main St");

        Contact contact2 = new Contact(
                "001",
                "Jane",
                "Brown",
                "0987654321",
                "456 Oak St");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class,
                () -> service.addContact(contact2));
    }

    @Test
    void testUpdateFirstName() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main St");

        service.addContact(contact);

        service.updateFirstName("001", "Jane");

        assertEquals("Jane",
                service.getContact("001").getFirstName());
    }

    @Test
    void testUpdateLastName() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main St");

        service.addContact(contact);

        service.updateLastName("001", "Brown");

        assertEquals("Brown",
                service.getContact("001").getLastName());
    }

    @Test
    void testUpdatePhone() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main St");

        service.addContact(contact);

        service.updatePhone("001", "5555555555");

        assertEquals("5555555555",
                service.getContact("001").getPhone());
    }

    @Test
    void testUpdateAddress() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main St");

        service.addContact(contact);

        service.updateAddress("001", "456 Oak Street");

        assertEquals("456 Oak Street",
                service.getContact("001").getAddress());
    }

    @Test
    void testUpdateInvalidPhone() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main St");

        service.addContact(contact);

        assertThrows(IllegalArgumentException.class,
                () -> service.updatePhone("001", "123"));
    }

    @Test
    void testUpdateInvalidAddress() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main St");

        service.addContact(contact);

        assertThrows(IllegalArgumentException.class,
                () -> service.updateAddress(
                        "001",
                        "This address is definitely longer than thirty characters"));
    }
}