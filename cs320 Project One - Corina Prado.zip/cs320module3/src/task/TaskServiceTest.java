package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

    @Test
    void testAddTask() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Homework",
                "Finish project");

        service.addTask(task);

        assertNotNull(service.getTask("001"));
    }

    @Test
    void testDeleteTask() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Homework",
                "Finish project");

        service.addTask(task);
        service.deleteTask("001");

        assertNull(service.getTask("001"));
    }

    @Test
    void testDuplicateTaskId() {

        TaskService service = new TaskService();

        Task task1 = new Task(
                "001",
                "Homework",
                "Finish project");

        Task task2 = new Task(
                "001",
                "Reading",
                "Read chapter");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class,
                () -> service.addTask(task2));
    }

    @Test
    void testUpdateName() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Homework",
                "Finish project");

        service.addTask(task);

        service.updateName("001", "Reading");

        assertEquals("Reading",
                service.getTask("001").getName());
    }

    @Test
    void testUpdateDescription() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Homework",
                "Finish project");

        service.addTask(task);

        service.updateDescription(
                "001",
                "Read chapter 5");

        assertEquals(
                "Read chapter 5",
                service.getTask("001").getDescription());
    }

    @Test
    void testUpdateInvalidName() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Homework",
                "Finish project");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class,
                () -> service.updateName(
                        "001",
                        "ThisNameIsLongerThanTwentyCharacters"));
    }

    @Test
    void testUpdateInvalidDescription() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Homework",
                "Finish project");

        service.addTask(task);

        assertThrows(IllegalArgumentException.class,
                () -> service.updateDescription(
                        "001",
                        "This description is intentionally made longer than fifty characters to fail."));
    }
}