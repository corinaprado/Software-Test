package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskTest {

    @Test
    void testValidTaskCreation() {

        Task task = new Task(
                "100",
                "Homework",
                "Finish CS320 milestone");

        assertEquals("100", task.getTaskId());
        assertEquals("Homework", task.getName());
        assertEquals("Finish CS320 milestone",
                task.getDescription());
    }

    @Test
    void testNullTaskId() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(null,
                        "Homework",
                        "Description"));
    }

    @Test
    void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("12345678901",
                        "Homework",
                        "Description"));
    }

    @Test
    void testNullName() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("1",
                        null,
                        "Description"));
    }

    @Test
    void testNameTooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("1",
                        "ThisNameIsLongerThanTwentyCharacters",
                        "Description"));
    }

    @Test
    void testNullDescription() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("1",
                        "Homework",
                        null));
    }

    @Test
    void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(
                        "1",
                        "Homework",
                        "This description is intentionally made longer than fifty characters to fail."));
    }
}