package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentTest {

    @Test
    void testValidAppointmentCreation() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment =
                new Appointment(
                        "001",
                        futureDate,
                        "Doctor appointment");

        assertEquals("001",
                appointment.getAppointmentId());

        assertEquals(futureDate,
                appointment.getAppointmentDate());

        assertEquals("Doctor appointment",
                appointment.getDescription());
    }

    @Test
    void testNullAppointmentId() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 86400000);

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        null,
                        futureDate,
                        "Doctor appointment"));
    }

    @Test
    void testAppointmentIdTooLong() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 86400000);

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "12345678901",
                        futureDate,
                        "Doctor appointment"));
    }

    @Test
    void testNullAppointmentDate() {

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "001",
                        null,
                        "Doctor appointment"));
    }

    @Test
    void testPastAppointmentDate() {

        Date pastDate =
                new Date(System.currentTimeMillis() - 86400000);

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "001",
                        pastDate,
                        "Doctor appointment"));
    }

    @Test
    void testNullDescription() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 86400000);

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "001",
                        futureDate,
                        null));
    }

    @Test
    void testDescriptionTooLong() {

        Date futureDate =
                new Date(System.currentTimeMillis() + 86400000);

        assertThrows(
                IllegalArgumentException.class,
                () -> new Appointment(
                        "001",
                        futureDate,
                        "This description is intentionally longer than fifty characters so the test fails."));
    }
}