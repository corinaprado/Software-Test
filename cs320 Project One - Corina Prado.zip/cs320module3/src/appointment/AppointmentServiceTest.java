package appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentServiceTest {

    @Test
    void testAddAppointment() {

        AppointmentService service =
                new AppointmentService();

        Appointment appointment =
                new Appointment(
                        "001",
                        new Date(System.currentTimeMillis() + 86400000),
                        "Doctor appointment");

        service.addAppointment(appointment);

        assertNotNull(
                service.getAppointment("001"));
    }

    @Test
    void testDeleteAppointment() {

        AppointmentService service =
                new AppointmentService();

        Appointment appointment =
                new Appointment(
                        "001",
                        new Date(System.currentTimeMillis() + 86400000),
                        "Doctor appointment");

        service.addAppointment(appointment);

        service.deleteAppointment("001");

        assertNull(
                service.getAppointment("001"));
    }

    @Test
    void testDuplicateAppointmentId() {

        AppointmentService service =
                new AppointmentService();

        Appointment appointment1 =
                new Appointment(
                        "001",
                        new Date(System.currentTimeMillis() + 86400000),
                        "Doctor appointment");

        Appointment appointment2 =
                new Appointment(
                        "001",
                        new Date(System.currentTimeMillis() + 172800000),
                        "Dental appointment");

        service.addAppointment(appointment1);

        assertThrows(
                IllegalArgumentException.class,
                () -> service.addAppointment(
                        appointment2));
    }
}