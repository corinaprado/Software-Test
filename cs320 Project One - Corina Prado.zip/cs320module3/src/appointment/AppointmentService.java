package appointment;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    private final Map<String, Appointment> appointments =
            new HashMap<>();

    public void addAppointment(Appointment appointment) {

        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null");
        }

        if (appointments.containsKey(
                appointment.getAppointmentId())) {

            throw new IllegalArgumentException(
                    "Duplicate appointment ID");
        }

        appointments.put(
                appointment.getAppointmentId(),
                appointment);
    }

    public void deleteAppointment(String appointmentId) {
        appointments.remove(appointmentId);
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}